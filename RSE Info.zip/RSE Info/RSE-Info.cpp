#include <iostream>
#include <cctype>
#include <conio.h>

int main()
{
    char choice;

    // Loop for the first prompt about RSE
    while (true)
    {
        std::cout << "Would you like to learn about RSE?\n";
        std::cout << "[Y] to continue [N] to exit: \n";
        choice = static_cast<char>(_getch());
        choice = static_cast<char>(tolower(choice));

        if (choice == 'y')
        {
            // Display RSE information
            std::cout << "\nRoblox Script extender is a tool for developers that allows users to upload local files into games. This can allow\nfor a wide plethora of things including, emulation, modding, customization, and a lot more. RSE was not intended to be\nused for the transfer of viruses or exploiting. RSE is expected to go live sometime in Q3/Q4 of 2025.\n\nNOTE:\"Roblox Script Extender's\" name is purely cosmetic. RSE does not actually extend Roblox's script, but instead\nuses a DLL injector.\n";

            // Loop for the second prompt about opportunities
            while (true)
            {
                std::cout << "\nWould you like to read about opportunities?\n";
                std::cout << "[Y] to continue [N] to exit:\n ";
                choice = static_cast<char>(_getch()); // Get new input without needing to press Enter
                choice = static_cast<char>(tolower(choice));

                if (choice == 'y')
                {
                    std::cout << "\nRSE is currently looking for 5-10 part-time developers, with extensive knowledge of C++.\nDo not expect pay; RSE will likely not get any money. If it does, however, 100% of what RSE makes will be divided\nevenly.\nClick any key to exit...";
                    _getch();
                    return 0; // Exit the program after showing opportunities
                }
                else if (choice == 'n')
                {
                    std::cout << "\nExiting the application. Goodbye!\n";
                    return 0; // Exit the program
                }
                else
                {
                    std::cout << "\nInvalid input! Please enter 'y' or 'n'.\n";
                }
            }
        }
        else if (choice == 'n')
        {
            std::cout << "\nExiting the application. Goodbye!\n";
            return 0; // Exit the program
        }
        else
        {
            std::cout << "Invalid input! Please enter 'y' or 'n'.\n";
        }
    }
}
